PUAI Color Palette Tokens
Format: HEX, RGB, CMYK
See puai-colors.json and puai-colors.css